import java.awt.*;
import javax.swing.*;
import model.*;
import java.util.*;
import javax.swing.border.Border;
import model.LaboratorySystem;


public class ReportPanel extends JPanel implements MyObserver {
    private LaboratorySystem laboratorySystem;
    private JTextArea patientTextArea;
    private JTextArea doctorTextArea;
    private JTextArea staffMemberTextArea;

    public ReportPanel(LaboratorySystem laboratorySystem) {
        this.laboratorySystem = laboratorySystem;
        setup();
        build();
    }

    private void setup() {
        //patient
        patientTextArea = createStyledTextArea();
        patientTextArea.setText(generatePatientReport());
        laboratorySystem.getPatients().attach(this);
        
        //Doctor
        doctorTextArea = createStyledTextArea();
        doctorTextArea.setText(generateDoctorReport());
        laboratorySystem.getDoctors().attach(this);
        
        //Staff
        staffMemberTextArea = createStyledTextArea();
        staffMemberTextArea.setText(generateStaffMemberReport());
        laboratorySystem.getStaffMembers().attach(this);

    }

    
    private JTextArea createStyledTextArea() {
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14)); // Set font size
        Border border = BorderFactory.createLineBorder(Color.BLUE, 1);
        setBorder(border);
        textArea.setBackground(new Color(173, 216, 230));
        return textArea;
    }

    private void build() {
        setLayout(new GridLayout(3, 1));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(createReportArea("Patients", patientTextArea));
        add(createReportArea("Doctors", doctorTextArea));
        add(createReportArea("Staff Members", staffMemberTextArea));
    }

    @Override
    public void update() {
        patientTextArea.setText(generatePatientReport());
        doctorTextArea.setText(generateDoctorReport());
        staffMemberTextArea.setText(generateStaffMemberReport());
    }

    private JPanel createReportArea(String title, JTextArea textArea) {
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(BorderFactory.createTitledBorder(title));
            Border border = BorderFactory.createLineBorder(Color.BLUE, 1);
            setBorder(border);
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            panel.add(scrollPane, BorderLayout.CENTER);
    
            return panel;
    }
    //Patients Report
    private String generatePatientReport() {
            StringBuilder reportText = new StringBuilder();
            for (model.Record record : laboratorySystem.getPatients().getAllRecords()) {
                if (record instanceof Patient) {
                    Patient patient = (Patient) record;
                    reportText.append("Patient ID: ").append(patient.getId()).append(" | ");
                    reportText.append("Name: ").append(patient.getName()).append(" | ");
                    reportText.append("Age: ").append(patient.getAge()).append(" | ");
                    reportText.append("Test Type: ").append(patient.getTestType()).append(" | ");
                    reportText.append("Doctor ID: ").append(patient.getAssignedDoctor().getId()).append(" | ");
                    reportText.append("Report Collection: ").append(patient.getReportStatus()).append("\n");
                reportText.append("---------------------------------------------------------------------------------------------------------------------------------------------\n");
            }
        }
        return reportText.toString();
    }
    //Doctors Report
    private String generateDoctorReport() {
        StringBuilder reportText = new StringBuilder();
        for (model.Record record : laboratorySystem.getDoctors().getAllRecords()) {
            if (record instanceof Doctor) {
                Doctor doctor = (Doctor) record;
                reportText.append("Doctor ID: ").append(doctor.getId()).append(" | ");
                reportText.append("Name: ").append(doctor.getName()).append(" | ");
                reportText.append("Emergency Contact: ").append(doctor.getEmergencyContact()).append(" | ");
                reportText.append("Speciality: ").append(doctor.getSpecialization()).append("\n");
                reportText.append("-----------------------------------------------------------------------------------------------------------------------------\n");
            }
        }
        return reportText.toString();
    }
    //Staff Members Report
    private String generateStaffMemberReport() {
        StringBuilder reportText = new StringBuilder();
        for (model.Record record : laboratorySystem.getStaffMembers().getAllRecords()) {
            if (record instanceof StaffMember) {
                StaffMember staffMember = (StaffMember) record;
                reportText.append("Staff Member ID: ").append(staffMember.getId()).append(" | ");
                reportText.append("Name: ").append(staffMember.getName()).append(" | ");
                reportText.append("Availability: ").append(staffMember.getAvailability()).append("\n");
                reportText.append("-------------------------------------------------------------------------------\n");
            }
        }
        return reportText.toString();
    }

}
