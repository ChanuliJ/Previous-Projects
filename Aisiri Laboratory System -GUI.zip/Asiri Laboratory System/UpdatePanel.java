import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import model.LaboratorySystem;
import model.Patient;
import javax.swing.border.Border;

public class UpdatePanel extends JPanel {
    private LaboratorySystem laboratorySystem;

    public UpdatePanel(LaboratorySystem laboratorySystem) {
        this.laboratorySystem = laboratorySystem;
        setup();
    }

    private void setup() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        Border border = BorderFactory.createLineBorder(Color.BLUE, 1);
        setBorder(border);
    
        //Patient ID
        JPanel idPanel = new JPanel();
        idPanel.setBackground(new Color(173, 216, 230)); // Light Blue
        JLabel enterIdLabel = new JLabel("Patient ID:");
        enterIdLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        JTextField idField = new JTextField(10);
        idPanel.add(enterIdLabel);
        idPanel.add(idField);
    
        //Status
        JPanel statusPanel = new JPanel();
        statusPanel.setBackground(new Color(173, 216, 230)); // Light Blue
        JLabel updateStatusLabel = new JLabel("Update Report Collection Status:");
        updateStatusLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        JComboBox<String> statusComboBox = new JComboBox<>(new String[]{"Collected", "Not Collected"});
        statusPanel.add(updateStatusLabel);
        statusPanel.add(statusComboBox);
    
        // Button
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(173, 216, 230)); // Light Blue
        JButton updateButton = new JButton("Update");
        updateButton.setFont(new Font("Arial", Font.BOLD, 18));
        buttonPanel.add(updateButton);
    
        //  glue to center vertically
        add(Box.createVerticalGlue());
    
        //  main panel
        add(idPanel);
        add(statusPanel);
        add(buttonPanel);
    
        // Add glue to center vertically
        add(Box.createVerticalGlue());

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int patientId = Integer.parseInt(idField.getText());
                    String selectedStatus = (String) statusComboBox.getSelectedItem();
                    boolean selectedStatusBool = "Collected".equals(selectedStatus);

                    Patient patientToUpdate = (Patient) laboratorySystem.getPatients().find(patientId);

                    if (patientToUpdate != null) {
                        laboratorySystem.getPatients().updateStatus(patientToUpdate, selectedStatusBool);
                        JOptionPane.showMessageDialog(null, "Report status updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Patient with ID " + patientId + " not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid patient ID. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
}
