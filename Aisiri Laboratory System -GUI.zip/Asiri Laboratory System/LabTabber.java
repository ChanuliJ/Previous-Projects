import javax.swing.*;
import java.awt.*;

import model.LaboratorySystem;
 
public class LabTabber extends JTabbedPane
{   
    private LaboratorySystem laboratorySystem;
    public LabTabber(LaboratorySystem laboratorySystem)
    {   
        this.laboratorySystem = laboratorySystem;
        setup();
        build();
        setVisible(true);   
    }
    
    private void setup()
    {   
    UIManager.put("TabbedPane.selected", new Color(102,179,200));
    UIManager.put("TabbedPane.contentAreaColor", Color.lightGray);
    setFont(new Font("Arial", Font.BOLD, 16)); 
    setTabPlacement(JTabbedPane.TOP);
    }
    
    private void build()
    {   
        add("Add New Records", new AddPanel(laboratorySystem));
        add("Update Existing Records", new UpdatePanel(laboratorySystem));
        add("The Report", new ReportPanel(laboratorySystem));
    }
}