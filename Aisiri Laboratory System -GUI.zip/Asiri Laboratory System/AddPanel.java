import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import model.*;

public class AddPanel extends JPanel {

  private LaboratorySystem laboratorySystem;

  public AddPanel(LaboratorySystem laboratorySystem) {
    this.laboratorySystem = laboratorySystem;
    setup();
    build();
  }

  private void setup() {
    setLayout(new GridLayout(3, 1));
  }

  private void build() {
    add(new AddPatientPanel(laboratorySystem.getPatients()));
    add(new AddStaffMemberPanel(laboratorySystem.getStaffMembers()));
    add(new AddDoctorPanel(laboratorySystem.getDoctors()));
  }

  public class AddPatientPanel extends JPanel {

    public Patients patients;

    public AddPatientPanel(Patients patients) {
      this.patients = patients;
      setup();
      build();
    }

    private void setup() {
      setLayout(new GridLayout(7, 2));
      Border border = BorderFactory.createLineBorder(Color.BLUE, 1);
      setBorder(border);
      setSize(300, 200);
    }

    private void build() {
      add(new JLabel("Add Patients"));
      add(new JLabel());

      add(new JLabel("Name"));
      JTextField nameField = new JTextField();
      add(nameField);

      add(new JLabel("Age"));
      JTextField ageField = new JTextField();
      add(ageField);

      add(new JLabel("TestType"));

      //JComboBox for Test Type
      JComboBox<TestType> testTypeComboBox = new JComboBox<>(TestType.values());
      add(testTypeComboBox);

      add(new JLabel("Doctor ID"));
      JTextField doctorIdField = new JTextField();
      add(doctorIdField);

      add(new JLabel("Report Collection"));

      //JComboBox for Report Collection
      JComboBox<String> reportCollectionComboBox = new JComboBox<>(
        new String[] { "No", "Yes" }
      );
      add(reportCollectionComboBox);

      JButton addButton = new JButton("Submit");
      add(addButton);

      JLabel successLabel = new JLabel("");
      add(successLabel);

      // Adding the action listener to the Add Patient''s Submit button
      addButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            // Retrieve values from text fields and combo boxes
            String name = nameField.getText();
            int age = Integer.parseInt(ageField.getText());
            TestType testType = (TestType) testTypeComboBox.getSelectedItem(); // Retrieve selected item
            int doctorId = Integer.parseInt(doctorIdField.getText());
            boolean reportStatus = reportCollectionComboBox.getSelectedItem().equals("Yes");

            int initialPatientCount = patients.size();

            boolean success = patients.createPatient(name,age,testType,doctorId,reportStatus);

            // Checking for successfull patiend add up
            if (success) {
              String successMessage ="Successfully added patient: " + (initialPatientCount + 1);
              JOptionPane.showMessageDialog(null,successMessage,"Success ",
              JOptionPane.INFORMATION_MESSAGE);
              successLabel.setText(successMessage);
            } else {
              // when unsuccessful
              String errorMessage =
                "Failed to add patient. Please check the inputs.";
              JOptionPane.showMessageDialog(null, errorMessage,"Error",JOptionPane.ERROR_MESSAGE);
              successLabel.setText(errorMessage);
            }
            // Use Timer to clear the message after 2 seconds
            Timer timer = new Timer(2000,
              new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {
                  successLabel.setText("");
                }
              }
            );
            timer.setRepeats(false); // Set to not repeat
            timer.start();
          }
        }
      );
    }
  }

  public class AddStaffMemberPanel extends JPanel {

    private StaffMembers staffMembers;

    public AddStaffMemberPanel(StaffMembers staffMembers) {
      this.staffMembers = staffMembers;
      setup();
      build();
    }

    private void setup() {
      setLayout(new GridLayout(5, 2));
      Border border = BorderFactory.createLineBorder(Color.BLUE, 1);
      setBorder(border);
    }

    private void build() {
      add(new JLabel("Add Staff Member"));
      add(new JLabel());

      add(new JLabel("Name"));
      JTextField nameField = new JTextField();
      add(nameField);

      add(new JLabel("Position"));
      JTextField positionField = new JTextField();
      add(positionField);

      add(new JLabel("Availability"));

      // Use a JComboBox for the availability options
      JComboBox<Availability> availabilityComboBox = new JComboBox<>(
        Availability.values()
      );
      add(availabilityComboBox);

      JButton addButton = new JButton("Submit");
      add(addButton);

      JLabel successLabel = new JLabel("");
      add(successLabel);

      // Add action listener to the "Add Staff Member" button
      addButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            // Retrieve values from text field and combo box
            String name = nameField.getText();
            String position = positionField.getText();
            Availability availability = (Availability) availabilityComboBox.getSelectedItem(); // Retrieve selected item

            // Get the count of staff members before adding the new staff member
            int initialStaffMemberCount = staffMembers.size();

            // Call the method in the StaffMembers class to add the new staff member
            staffMembers.addStaffMember(name, position, availability);
            boolean success = staffMembers.size() > initialStaffMemberCount;

            // Check if the staff member was added successfully

            if (success) {
              String successMessage = "Staff Member "  + (initialStaffMemberCount +1 )+  " added to the system. ";
              JOptionPane.showMessageDialog(null, successMessage, "Success ", JOptionPane.INFORMATION_MESSAGE);
              
              successLabel.setText(successMessage);
              
            } else {
              // Display unsuccessful message
              String errorMessage = "Failed to add the staff Member. Please check the inputs.";
              JOptionPane.showMessageDialog(null, errorMessage, "Error ", JOptionPane.ERROR_MESSAGE);
              
              successLabel.setText(errorMessage);
            }
            // Use Timer to clear the message after 2 seconds
            Timer timer = new Timer(2000,
              new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent arg0) {
                  successLabel.setText("");
                }
              }
            );
            timer.setRepeats(false); // Set to not repeat
            timer.start();
          }
        }
      );
    }
  }

  public class AddDoctorPanel extends JPanel {

    private Doctors doctors;

    public AddDoctorPanel(Doctors doctors) {
      this.doctors = doctors;
      setup();
      build();
    }

    private void setup() {
      setLayout(new GridLayout(5, 2)); // Adjust rows and columns as needed
      Border border = BorderFactory.createLineBorder(Color.BLUE, 1);
      setBorder(border);
      setSize(400, 200); // Adjust size as needed
    }

    private void build() {
      add(new JLabel("Add Doctor"));
      add(new JLabel());

      add(new JLabel("Name"));
      JTextField nameField = new JTextField();
      add(nameField);

      add(new JLabel("Emergency Contact"));
      JTextField emergencyContactField = new JTextField();
      add(emergencyContactField);

      add(new JLabel("Speciality"));
      JTextField specialityField = new JTextField();
      add(specialityField);

      JButton addButton = new JButton("Submit");
      add(addButton);

      JLabel successLabel = new JLabel("");
      add(successLabel);

      // Add action listener to the "Add Doctor" button
      addButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            // Retrieve values from text fields
            String name = nameField.getText();
            String emergencyContact = emergencyContactField.getText();
            String speciality = specialityField.getText();

            // Get the count of doctors before adding the new doctor
            int initialDoctorCount = doctors.size();

            // Call the method in the Doctors class to add the new doctor
            doctors.addDoctor(name, emergencyContact, speciality);
            boolean success = doctors.size() > initialDoctorCount;

            // Check if the doctor was added successfully
            if (success) {
              String successMessage = "Doctor "  + (initialDoctorCount +1 )+  " added to the system. ";
              JOptionPane.showMessageDialog(null, successMessage, "Success ", JOptionPane.INFORMATION_MESSAGE);
              
              successLabel.setText(successMessage);
            } else {
              // Display unsuccessful message
              String errorMessage = "Failed to add the Doctor. Please check the inputs.";
              JOptionPane.showMessageDialog(null, errorMessage, "Error ", JOptionPane.ERROR_MESSAGE);
              
              successLabel.setText(errorMessage);
            }

            // Use Timer to clear the message after 2 seconds
            Timer timer = new Timer(2000,
              new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent arg0) {
                  successLabel.setText("");
                }
              }
            );
            timer.setRepeats(false); // Set to not repeat
            timer.start();
          }
        }
      );
    }
  }
}
