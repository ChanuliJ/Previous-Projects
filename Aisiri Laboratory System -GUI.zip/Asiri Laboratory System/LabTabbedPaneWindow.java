import javax.swing.*;
import model.LaboratorySystem;
 
public class LabTabbedPaneWindow extends JFrame
{   
    private LaboratorySystem laboratorySystem;
    
    public LabTabbedPaneWindow(LaboratorySystem laboratorySystem)
    
    {   
        super("Asiri Laboratory System " );
        this.laboratorySystem = laboratorySystem;
        setup();
        build();
        setVisible(true);   
    }
    
    private void setup()
    {   
        setSize(800,550);
        setLocation(350, 50);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    private void build()
    {   
        LabTabber pane = new LabTabber(laboratorySystem);
        add(pane);  
    }
}
