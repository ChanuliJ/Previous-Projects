package model;

public class LaboratorySystem extends Updater {
    private Doctors doctors = new Doctors();
    private Patients patients = new Patients(doctors);
    private StaffMembers staffMembers = new StaffMembers();
    
    public LaboratorySystem() {  
        doctors.setupDoctors();
        patients.setupPatients();
        staffMembers.setupStaffMembers();
    }
    
    public Patients getPatients()
    {
      return patients;  
    }
    
    public Doctors getDoctors()
    {
      return doctors;  
    }
    
    public StaffMembers getStaffMembers()
    {
      return staffMembers;  
    }
    
    @Override
    public String toString() {
        return "";
    }
}