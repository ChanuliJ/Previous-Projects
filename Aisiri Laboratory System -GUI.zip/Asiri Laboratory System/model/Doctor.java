package model;

public class Doctor extends Record {
    
    private String emergencyContact;
    private String speciality;
    
    public Doctor(int id, String name, String emergencyContact,String speciality) {
        super(id, name);
        this.emergencyContact = emergencyContact;
        this.speciality = speciality;
    }
    
    public String getSpecialization() {
        return speciality;
    }
    
    public String getEmergencyContact(){
        return emergencyContact;
    }
    
    @Override
    public String toString(){
        return "\nDoctor ID: " + getId() +
                ", Name: " + getName() +
                ", Speciality: " + getSpecialization() +
                ", Emergency Contact Number: " + getEmergencyContact() ;
    }
}