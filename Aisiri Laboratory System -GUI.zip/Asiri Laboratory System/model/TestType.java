package model;

public enum TestType {
    CBC,
    FBC,
    URINE,
    XRAY,
    MRI,
    ENDOSCOPY;
}
