package model;
import java.util.*;

public class StaffMembers extends Records {

    public void addStaffMember(StaffMember staffMember) {
        add(staffMember);
        updateViews();
    }

    public void setupStaffMembers() {
        addStaffMember(new StaffMember(1, "John Smith", "Cashier",Availability.AVAILABLE));
        addStaffMember(new StaffMember(2, "Jane Doe", "Nurse", Availability.ON_LEAVE));
        addStaffMember(new StaffMember(3, "Bob Johnson", "Assistant", Availability.AVAILABLE));
        updateViews();
    }
    
    public void addStaffMember(String name, String position, Availability availability) {
        // checking whether the name and position fields are empty or null
        if (super.isNullOrEmpty(name)|| super.isNullOrEmpty(position)) {
            return;
        }
    
        int id = genID();
    
        StaffMember newStaffMember = new StaffMember(id, name, position , availability);
        addStaffMember(newStaffMember);
        
        updateViews();
    }
}
