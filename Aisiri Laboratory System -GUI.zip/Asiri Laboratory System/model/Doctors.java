package model;

public class Doctors extends Records {

    public void addDoctor(Doctor doctor) {
        add(doctor);
        updateViews();
    }

    public void setupDoctors() {
        add(new Doctor(1, "Dr. Gray Smith", "133-456-7890", "Cardiology"));
        add(new Doctor(2, "Dr. De Johnson", "967-654-3210", "Hematology"));
        add(new Doctor(3, "Dr. Carl Bossman", "777-898-9999", "Cardiology"));
        updateViews();
    }
  
    public void addDoctor(String name,String emergencyContact,String specialization) {
        int id = genID();
        //cheking whether the name, EmergencyContact or the specialization are null or empty
        if (super.isNullOrEmpty(name)|| super.isNullOrEmpty(emergencyContact) ||super.isNullOrEmpty(specialization)) {
        return;
        }
        Doctor newDoctor = new Doctor(id, name, emergencyContact, specialization);
        addDoctor(newDoctor);
        
        updateViews();
    }
    
    public Doctor findDoctorById(int doctorId) {
        for (Record record : getAllRecords()) {
            Doctor doctor = (Doctor) record;
                if (doctor.getId() == doctorId) {
                    return doctor;
                }
        }
        return null;
    }
}
