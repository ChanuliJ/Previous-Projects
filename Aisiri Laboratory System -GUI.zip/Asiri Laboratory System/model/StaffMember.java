package model;

public class StaffMember extends Record {
    private String position;
    private Availability availability;
    
    public StaffMember(int id, String name,String position, Availability availability ) {
       super(id, name);
       this.position = position;
       this.availability = availability;
    }
     
    public Availability getAvailability() {
        return availability;
    }
    
    public String getPosition() {
        return position;
    }
    
    @Override
    public String toString()
    {
     return "Staff ID: " + getId() +
                    ", Name: " + getName() +
                    ", Position: " + getPosition()+ 
                    ", The Availability: " + getAvailability();   
    }
}