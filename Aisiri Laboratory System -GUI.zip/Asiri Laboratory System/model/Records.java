package model;
import java.util.*;
public abstract class Records extends Updater
{
    protected LinkedList<Record> records = new LinkedList<Record>();
    
    public Records(){
    }
    
    public void add(Record record){
        records.add(record);   
        updateViews();
    }
    
    public Record find(int id){   
        for (Record record : records)
        {   
            if (record.matches(id))
                return record;  
        }
        return null;    
    }
    
    public int genID(){
        int lastID = records.size();
        return lastID+1;
    }
    
    public int size(){
        return records.size();
    }
    
    public LinkedList<Record> getAllRecords() {
        return records;
    }
    
    public LinkedList<Record> getAllrecords(){
        return records;
    }
    
    public boolean isNullOrEmpty(String value) {
    return value == null || value.isEmpty();
    }
    
    public String toString(){
        String s = "";
        for (Record record : records)
            s += "\n" + record.toString();
        return s;
    }
}

