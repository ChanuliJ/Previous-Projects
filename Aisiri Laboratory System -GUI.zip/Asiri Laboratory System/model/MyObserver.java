package model;

public interface MyObserver 
{
    void update();
}