package model;

public class Patients extends Records {
    private Doctors doctors;
    public Patients(Doctors doctors){
        this.doctors = doctors;
    }
    
    public void setupPatients() {
        add(new Patient(1, "John carlson", TestType.CBC, 25, false, doctors.findDoctorById(1)));
        add(new Patient(2, "Janna Ferdinando", TestType.FBC, 30, true,doctors.findDoctorById(2)));
        add(new Patient(3, "Bob calson", TestType.URINE, 40, false, doctors.findDoctorById(3)));
        updateViews();
    }
    
    public boolean createPatient(String name, int age, TestType testType, int doctorId, boolean reportStatus) {
        // Check if name or age is empty or null
        if (super.isNullOrEmpty(name) || age <0) {
            return false;
        }
    
        int id = genID();
        Patient newPatient = new Patient(id, name, testType, age, reportStatus, null);
        
        // Checking if process of assigning a doctor is successful
            if (!assignDoctor(newPatient, doctorId)) {
            return false;
        }

        int initialPatientCount = size();
        addPatient(newPatient);
        return size() > initialPatientCount;
    }

    public boolean assignDoctor(Patient newPatient, int selectedDoctorId) {
        Record selectedRecord = doctors.find(selectedDoctorId);
    
        if (selectedRecord instanceof Doctor) {
            Doctor selectedDoctor = (Doctor) selectedRecord;
            newPatient.setDoctor(selectedDoctor);
            return true; // assigned doctor successfully 
        } else {
            return false; // Stop creation
        }
    }

    public void addPatient(Patient p){
        add(p);
        updateViews();
    }
    
    private Patient findPatientById(int patientId) {
        Record record = find(patientId);
    
        if (record instanceof Patient) {
            return (Patient) record;
        }
    
        return null;
    }
    
    public void updateStatus(Patient patientToUpdate, boolean newReportStatus) {
        patientToUpdate.setReportStatus(newReportStatus);
        updateViews();
    }
}