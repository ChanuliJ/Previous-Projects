package model;

public enum Availability {
    AVAILABLE,
    ON_LEAVE,
    ON_BREAK;
}
