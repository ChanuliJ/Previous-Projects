import model.LaboratorySystem;
public class Root
{
    public Root()
    {
       LaboratorySystem laboratorySystem = new LaboratorySystem();
       new LabTabbedPaneWindow(laboratorySystem);
    }
}
