from socket import *
import sys

def http_client(server_host, server_port, filename):
    client_socket = None
    try:
        client_socket = socket(AF_INET, SOCK_STREAM)
        client_socket.connect((server_host, server_port))

        request = f"GET /{filename} HTTP/1.1\r\nHost: {server_host}\r\n\r\n"
        client_socket.sendall(request.encode())

        response = client_socket.recv(2048)
        print(response.decode())  # Print the response header

        # Add code to print or display the content received from the server
        content = client_socket.recv(2048)
        print(content.decode())

    except Exception as e:
        print(f"Error: {e}")
    finally:
        if client_socket:
            client_socket.close()

if __name__ == "__main__":
    if len(sys.argv) != 4:
        sys.exit(1)

    server_host = sys.argv[1]
    server_port = int(sys.argv[2])
    filename = sys.argv[3]

    http_client(server_host, server_port, filename)
