from socket import *
import sys
import threading

server_Socket = socket(AF_INET, SOCK_STREAM)
serverPort = 11554  # available port
server_Socket.bind((gethostname(), serverPort))
server_Socket.listen(2) #listening


def handle_client(connection_Socket, address):

    try:
        message = connection_Socket.recv(2048).decode()

        filename = message.split()[1]
        print("Trying to send the File " +filename)
        with open(filename[1:], 'r') as file:
            outputdata = file.read()

        connection_Socket.send("HTTP/1.1 200 OK\r\n\r\n".encode())
        connection_Socket.send(outputdata.encode())
        print(f" Sent the response to",address)
        # Close the connection socket
        connection_Socket.close()

    except IOError:
        # file not found
        connection_Socket.send("HTTP/1.1 404 Not Found\r\n\r\n".encode())
        connection_Socket.send(
            "<!doctype html><html><head></head><body><h2>404 Not Found!</h2></body></html>\r\n".encode())

        print(f" Sent the error response to",address)
    finally:
        #closing the connection
        connection_Socket.close()

print(" Server : Waiting to establish the connection ...")

while True:
    #connection establishment
    connection_Socket, address = server_Socket.accept()

    #new threads
    client_thread = threading.Thread(target=handle_client, args=(connection_Socket, address))
    print("---------------------------------------")
    print(f"New thread created for the {address}")
    client_thread.start() #starting a new thread





