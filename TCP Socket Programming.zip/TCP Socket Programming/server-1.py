#import socket module
from socket import *
#In order to terminate the program
import sys

serverSocket = socket(AF_INET, SOCK_STREAM)
#Prepare a sever socket
serverPort = 11555
serverSocket.bind((gethostname(), serverPort))
serverSocket.listen(1) #listening

while True:
    print('--- THE SERVER IS READY TO SERVE ---')
    connectionSocket, addr = serverSocket.accept()
    try:
        message = connectionSocket.recv(4096).decode()
        filename = message.split()[1]
        file = open(filename[1:])
        outputdata = file.read()
        #send one HTTP header line into socket

        connectionSocket.send("HTTP/1.1 200 OK\r\n\r\n".encode())

        for i in range(0, len(outputdata)):
            connectionSocket.send(outputdata[i].encode())
        connectionSocket.send("\r\n".encode())
        connectionSocket.close() # client connection socket is closed

    except IOError:
        #Send response message for file not found
        connectionSocket.send("HTTP/1.1 404 Not Found\r\n\r\n".encode())
        connectionSocket.send("<!doctype html><html><head></head><body><h2>404 Not Found!</h2></body></html>\r\n".encode())
        connectionSocket.close()
#closing the client
serverSocket.close()
sys.exit()
