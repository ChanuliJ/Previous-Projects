import time
from socket import *
from itertools import count
serverIP = "192.168.1.27"
serverPort = 11985


def create_client_socket():
    return socket(AF_INET, SOCK_DGRAM)


def timeout_message(sequence_num):
    print(f'Request timed out for ping : {sequence_num}')


def connection_reset_message(sequence_num):
    print(f'Connection reset by the server for ping # {sequence_num}')


def ping_message(server_address, sequence_num, calculated_rtt):
    print(f'The Response from {serverIP} : ping : {sequence_num} | RTT: {calculated_rtt:.6f} seconds')


def calculate_packet_loss_rate(num_of_pings, rtt_times):
    return (num_of_pings - len(rtt_times)) / num_of_pings * 100  # calculating the packet loss rate

# Creating the UDP Socket
clientSocket = create_client_socket()

# timeout is set up for 1 second
clientSocket.settimeout(1)

# variables need to track RTT related data
num_of_pings = 10
rtt_times = []
pings_min_rtt = []
pings_max_rtt = []
index_max_rtt = None  # To find the ping number with maximum RTT

# sending 10 pings
for sequence_num in count(start=1, step=1):
    if sequence_num > num_of_pings:
        break

    message = f'Ping {sequence_num} {time.time()}'

    # Record sending time
    send_time = time.time()

    # Send the ping to the server
    clientSocket.sendto(message.encode(), (serverIP, serverPort))

    try:
        # Receive the response of server
        response, server_address = clientSocket.recvfrom(1024)

        # RTT Calculation
        calculated_rtt = time.time() - send_time
        rtt_times.append(calculated_rtt)

        # Updating the ping number for minimum RTT
        if calculated_rtt == min(rtt_times):
            pings_min_rtt.append(sequence_num)

        # Updating the ping number for maximum RTT
        if index_max_rtt is None or calculated_rtt > rtt_times[index_max_rtt]:
            index_max_rtt = len(rtt_times) - 1
            pings_max_rtt = [sequence_num]
        elif calculated_rtt == rtt_times[index_max_rtt]:
            pings_max_rtt.append(sequence_num)

        # printing the summary of response messages
        ping_message(server_address, sequence_num, calculated_rtt)

    except timeout:
        # Handle timeout for 1 second
        timeout_message(sequence_num)

    except ConnectionResetError:
        # Handle the reset connections of the server
        connection_reset_message(sequence_num)


# printing RTT statistics
if rtt_times:
    print(f'\nMinimum Round Trip Time : {min(rtt_times):.6f} seconds')  # min RTT
    print(f'Maximum Round Trip Time : {rtt_times[index_max_rtt]:.6f} seconds | ping {pings_max_rtt}')  # max RTT
    print(f'Average Round Trip Time : {sum(rtt_times) / len(rtt_times):.6f} seconds')  # avg RTT

    print(f'Overall Packet Loss Rate: {calculate_packet_loss_rate(num_of_pings, rtt_times):.2f}%')  # packet loss rate

# Close the socket
clientSocket.close()
