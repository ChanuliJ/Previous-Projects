from socket import *
import time

server_name = "192.168.1.27"
server_port = 11986
# create the server socket


def create_server_socket():
    return socket(AF_INET, SOCK_DGRAM)


server_socket = create_server_socket()

# binding the socket
server_socket.bind((server_name, server_port))

server_socket.settimeout(3)  # Set a timeout value in seconds
print('Server is running on : ' + server_name)

# keep tracking the consecutive packet losses
consecutive_packet_losses = 0
MAX_CONSECUTIVE_LOSSES = 2  # setting the maximum consecutive packet losses to be tolerated
MAX_TIME_DIFFERENCE = 0.00001


def calculate_time_difference(timestamp):
    current_time = time.time()
    return current_time - timestamp


while True:
    try:
        start_time = time.time()  # Record the start time of packet reception
        message, clientAddress = server_socket.recvfrom(1024)
        sequence_number, timestamp = message.decode().split(',')
        sequence_number = int(sequence_number)
        timestamp = float(timestamp)

        calculate_time_difference(timestamp)
        # Calculate the time difference
        time_difference = calculate_time_difference(timestamp)

        # Check for lost packets
        if sequence_number >= 1 and time_difference > MAX_TIME_DIFFERENCE:
            print(f"Heartbeat Lost from client {server_name} with sequence number {sequence_number}. Delay: {time_difference:.5f} seconds")
            consecutive_packet_losses += 1
        else:
            consecutive_packet_losses = 0  # Reset consecutive losses count
            # Print a message when a Heartbeat packet is received
            print(f"Heartbeat received from {server_name} with sequence number {sequence_number}. Delay: {time_difference:.5f} seconds")
            server_socket.sendto(f"Acknowledgment for sent heartbeat {sequence_number}".encode(), clientAddress)
        # Respond to the client with an acknowledgment
        server_socket.sendto(f"Acknowledgment for received heartbeat {sequence_number}".encode(), clientAddress)

    except timeout:
        print(f"Timeout: No Heartbeat packet received from {server_name} with sequence number {sequence_number}. received within the specified time.")

        consecutive_packet_losses += 1
        # Check if consecutive losses exceeds the limit
    if consecutive_packet_losses >= MAX_CONSECUTIVE_LOSSES:
            print(f"\nrecorded {consecutive_packet_losses} consecutive packet losses. Client application may have stopped")
