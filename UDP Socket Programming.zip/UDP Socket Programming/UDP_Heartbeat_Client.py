from socket import *
import time

serverName = "192.168.1.27"
serverPort = 11986

def create_client_socket():
    return socket(AF_INET, SOCK_DGRAM)

clientSocket = create_client_socket()
sequence_number = 1

while True:
    try:
        # Send Heartbeat packet to the server with sequence number and timestamp
        timestamp = time.time()
        message = f"{sequence_number},{timestamp}"
        clientSocket.sendto(message.encode(), (serverName, serverPort))

        # Wait for acknowledgment from the server
        acknowledgment, serverAddress = clientSocket.recvfrom(1024)
        print(acknowledgment.decode())

        sequence_number += 1
        time.sleep(1.5)  # Adjust the interval as needed

    except ConnectionResetError:
        print("Connection with the server was forcibly closed. Exiting...")
        sequence_number += 1
        break
