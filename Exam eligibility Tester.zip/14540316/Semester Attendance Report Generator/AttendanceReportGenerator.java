import java.util.Scanner;
import java.math.*;
public class AttendanceReportGenerator {
        private Scanner scanner;
        private final int MAXIMUM_WEEKS = 11;
        private final int MAXIMUM_WEEKLY_SESSIONS = 3;
        private String[] moduleIds = {"IWBS001", "IIIS001", "IITC001", "IPRG001"};
        Student defaultStudent = new Student();
        Session[] sessions = new Session[3];
        double[] requiredPercentages = new double[4];

        public AttendanceReportGenerator() {
        scanner = new Scanner(System.in);
    }
    
    public void main(String[] args) {
        AttendanceReportGenerator generator = new AttendanceReportGenerator();
        System.out.println("**_______________________________________________________**");
        System.out.println("Welcome to the Attendance Report Generator program!");
        
            scanner = new Scanner(System.in);
            char choice;
            while (true) {
                System.out.println("\n              Menu                " );
                System.out.println("Select an option to proceed." );
                System.out.println("\nA. Start generating the Semester Attendance report ");
                System.out.println("B. More details about the program"  );
                System.out.println("C. Guide to use"  );
                System.out.println("Q. Exit");
                System.out.print("\nEnter your choice: ");
    
                choice = scanner.nextLine().toUpperCase().charAt(0); // Convert to uppercase and get the first character
    
                switch (choice) {
                    case 'A':
                    generator.checkAttendance();
                        break;
                    case 'B':
                        System.out.println("The Semester Attendance Report Generator is a Java program designed to assist students in calculating their attendance percentage and eligibility \nfor exams based on the attendance records of various modules within a semester. \nThis interactive program allows students to input their attendance data and provides detailed reports regarding their eligibility status.");
                        
                        break;
                    case 'C':
                        System.out.println("Starting the Program: Upon launching the program, you'll be presented with a menu that provides different options to choose from. \nHere's how you can navigate through the program:- \nFirst the program prompts you for your personal details. \nAfter you enter those details it will prompt again to enter the required percentages so the program can calculate and output data about your eligibility. \nHope you make the best use out of this.");
                        System.out.println("\nRefer this sample answers to have an idea about the program inputs: \n" + defaultStudent.toString());
                        break;
                    case 'Q':
                        System.out.println("Thank you for using the Attendance Report Generator.");
                        return;
                    default:
                        System.out.println("Invalid choice. Please select a valid option.");
                        break;
                }
            }
        }
    
     public void checkAttendance() {
          String name = requestName();
          String studentId = requestStudentId();
          int currentWeekCount = requestCurrentWeekCount();
          double[] requiredPercentages = requestRequiredPercentages();
          
            sessions[0] = new Session("TutorialA");
            sessions[1] = new Session("TutorialB");
            sessions[2] = new Session("LabORPcpc");
               
           // Modifications
           modifySessionArray();
           System.out.println("Please Enter the following details to check your exam eligibility. ");
           Scanner scanner = new Scanner(System.in);
           int attendedSessionsArray[] = new int[sessions.length]; // store attended sessions for each module
           
                for (int i = 0; i <moduleIds.length; i++) {
                    System.out.println("-----------------------------------------------------------");
                    System.out.println("\nExam Eligibility checker:  "+ moduleIds[i]);
                  
                for (int j = 0; j < sessions.length; j++) {
                    
                    System.out.print("Enter your previous attendance for " + sessions[j].getSessionName() + " (0-" + currentWeekCount + "): ");
                    int attendedSessions = scanner.nextInt();
                    scanner.nextLine();
                
                    while (attendedSessions < 0 || attendedSessions > currentWeekCount) {
                        System.out.println("Invalid input. Please enter a value between 0 and " + currentWeekCount + ".");
                        System.out.println("----------------------------------------------------------------------------");
                        System.out.println("Enter attendance for " + sessions[j].getSessionName() + " (0-" + currentWeekCount + "): ");
                        attendedSessions = scanner.nextInt();
                        scanner.nextLine();
                    }
                
                    attendedSessionsArray[j] = attendedSessions;
    
                }
                
                int totalAttendedSessions = 0;
                
                for (int k = 0; k < attendedSessionsArray.length; k++) {
                    totalAttendedSessions += attendedSessionsArray[k];
                 }
                
                    // Calculate  attendance percentage 
                    double attendedPercentage = calculateAttendancePercentage(totalAttendedSessions, currentWeekCount);
                    boolean isEligible = attendedPercentage >= requiredPercentages[i];
                    int remainingSessions;
                    int requiredSessions;
                    if (isEligible) {
                        System.out.println("\nCongratulations! \nYou are eligible for the exam. \nTotal sessions attended: " + totalAttendedSessions + "\nThe required percentage for " + moduleIds[i] + " module is " +requiredPercentages[i] + "% \nAttended percentage: " + attendedPercentage + "%");
    
                    } 
                    else {
                        System.out.println("\nUnfortunately, you are not eligible for the exam. \nTotal sessions attended: " + totalAttendedSessions + "\nThe required percentage for " + moduleIds[i] + " module is " +requiredPercentages[i] +"% \nAttended percentage: " + attendedPercentage + "%");
     
                        
                         remainingSessions = (MAXIMUM_WEEKS - currentWeekCount) * MAXIMUM_WEEKLY_SESSIONS;
                         System.out.println("Remaining Sessions : "+remainingSessions );
                        
                         requiredSessions = (int) Math.ceil((requiredPercentages[i] * MAXIMUM_WEEKLY_SESSIONS * MAXIMUM_WEEKS / 100) - totalAttendedSessions);
                        if(currentWeekCount==11){
                             System.out.println("\nStudent should meet the lecturer and discuss the issue immediately." );
                            }
                        else if (currentWeekCount<11 && remainingSessions >= requiredSessions) {
                            System.out.println("\nStudent needs to attend at least " + requiredSessions + " out of remaining " + remainingSessions + "  in order to be eligible for the exam.");
                        } else {
                            System.out.println("\nEven if you attend all the remaining "+ remainingSessions + " sessions, it is impossible to achieve the reqiered percentage. \n Student should meet the lecturer and discuss the issue immediately." );
                        }
                    }
                
        }
            
            
    }

    
       public String requestName() {
        System.out.print("Enter the name of the student: ");
        return scanner.nextLine();
    }

    
    public String requestStudentId() {
        System.out.print("Enter the student ID: ");
        return scanner.nextLine(); 
    }
    
    private int requestCurrentWeekCount() {
       System.out.print("To calculate the average, please enter the current week number(1-11): ");
       int currentWeekCount = scanner.nextInt();
       scanner.nextLine();
       if (currentWeekCount >= 1 && currentWeekCount <= MAXIMUM_WEEKS) {
            return currentWeekCount;
        } else 
        {
            System.out.println("Invalid input. Please enter a week count between 1 and 11.");
            return requestCurrentWeekCount(); //  call to re-prompt
        }
    }
    

    public double[] requestRequiredPercentages() {
        
        double requiredPercentages[] = new double[4]; // Semester 1 - 4 modules
    
        boolean validInput = false;
    
        while (!validInput) {
            System.out.print("Do you have a common required attendance percentage for all modules? (yes/no): ");
            String commonPercentageChoice = scanner.nextLine();
    
            if (commonPercentageChoice.equalsIgnoreCase("yes")) {
                System.out.print("Enter the common required attendance percentage for all modules (0-100): ");
                double commonRequiredPercentage = scanner.nextDouble();
                scanner.nextLine();
                
                while (commonRequiredPercentage < 0 || commonRequiredPercentage > 100) {
                    System.out.println("Invalid input. Please enter a percentage between 0 and 100.");
                    System.out.print("Enter the common required attendance percentage for all modules (0-100): ");
                    commonRequiredPercentage = scanner.nextDouble();
                    scanner.nextLine();
                }
    
                // Apply the common percentage to all subjects
                for (int i = 0; i < requiredPercentages.length; i++) {
                    requiredPercentages[i] = commonRequiredPercentage;
                }
                
                validInput = true;
            }    
            else if (commonPercentageChoice.equalsIgnoreCase("no")) {
                // Collect individual percentages
                for (int i = 0; i < requiredPercentages.length; i++) {
                    System.out.print("Enter the required attendance percentage for module " + moduleIds[i] + " (0-100): ");
                    double requiredPercentage = scanner.nextDouble();
                    scanner.nextLine();
    
                    while (requiredPercentage < 0 || requiredPercentage > 100) {
                        System.out.println("Invalid input. Please enter a percentage between 0 and 100.");
                        System.out.print("Enter the required attendance percentage for module " + moduleIds[i] + " (0-100): ");
                        requiredPercentage = scanner.nextDouble();
                        scanner.nextLine();
                    }
    
                    requiredPercentages[i] = requiredPercentage;
                }
                
                validInput = true;
            } 
            else {
                System.out.println("Invalid input. Please enter either 'yes' or 'no'.");
            }
        }
        return requiredPercentages;
    }

        public void modifySessionArray() {
        System.out.println("\n  Modify Sessions:");
        System.out.println("\n1. Continue with default UTS sessions ");
        System.out.println("2. Change only 1 session ");
        System.out.println("3. Change all session names");
        System.out.print("\nEnter your choice: ");
            
        int selection = scanner.nextInt();
        scanner.nextLine(); // Consume newline
    
        switch (selection) {
        case 1:
            
            System.out.println("Sessions  have been initialized according to UTS college semester plan : (Sessions are - TutorialA, TutorialB, LabOrPppc)");
            break;
        case 2:
            // Change only 1 session array element
            System.out.print("\nYou can change a specific session name here ");
            int sessionNum;
            do {
                
                System.out.print("\nPlease enter the session number you want to modify (1-" + sessions.length + "): ");
                sessionNum = scanner.nextInt();
                scanner.nextLine();
                // error handling
                if (sessionNum < 1 || sessionNum > sessions.length) {
                    System.out.println("Invalid session number. Please enter a valid session number.");
                }
            } while (sessionNum < 1 || sessionNum > sessions.length);
        
            System.out.println("Enter a new name for session " + sessionNum + ": ");
            String newName = scanner.nextLine();
            sessions[sessionNum - 1] = new Session(newName);
            System.out.println("Session " + sessionNum + " element has been updated.");
            
            break;
    
        case 3:
            // Change all session array elements
            System.out.println("You can change all 3 session names here");
            for (int i = 0; i < sessions.length; i++) {
                
                System.out.println("Enter new name for session " + (i + 1) + ": ");
                String newName2 = scanner.nextLine();
                sessions[i] = new Session(newName2);
            }
            System.out.println("\n Updated Session List.");
            
            for (int i = 0; i < sessions.length; i++) {
                System.out.println("Session " + (i + 1) + ": " + sessions[i].getSessionName());
            }
            break;
        default:
            System.out.println("Invalid choice.");
            break;
        }
    }
    
    
    private int calculateTotalSessions(int currentWeekCount) {
         if (currentWeekCount == MAXIMUM_WEEKS) {
                return MAXIMUM_WEEKS * MAXIMUM_WEEKLY_SESSIONS;
            } else {
                return currentWeekCount * MAXIMUM_WEEKLY_SESSIONS;
            }
        }
    
        
    private double calculateAttendancePercentage(int totalAttendedSessions, int currentWeekCount) {
        int totalSessions = calculateTotalSessions(currentWeekCount);
        return ((double) totalAttendedSessions / totalSessions) * 100;
         }
    }

    


