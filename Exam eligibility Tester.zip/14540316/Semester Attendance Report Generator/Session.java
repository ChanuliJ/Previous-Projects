public class Session {
    private String sessionName;
    private int attendedSessions;
    private String newName; 
    public Session(String sessionName) {
        this.sessionName = sessionName;
        this.attendedSessions = 0;
    }
    
    public String getSessionName() {
        return sessionName;
    }
    public int getAttendedSessions() {
        return attendedSessions;
    }

    public void setAttendedSessions(int attendedSessions) {
        this.attendedSessions = attendedSessions;
    }
    public String setSessionName(String newName){
    return newName;
    }
}
