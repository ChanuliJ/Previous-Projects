public class Student {
    private String name;
    private String studentID;
    private String moduleID;
    private double requiredPercentage;
    private int currentWeekCount;

    public Student(String name, String studentID, String moduleID, double requiredPercentage, int currentWeekCount) {
        this.name = name;
        this.studentID = studentID;
        this.moduleID = moduleID;
        this.requiredPercentage = requiredPercentage;
        this.currentWeekCount = currentWeekCount;
    }

    public Student() {
        this.name = "Chanuli";
        this.studentID = "14540318";
        this.moduleID = "IPRG001";
        this.requiredPercentage = 80.0;
        this.currentWeekCount = 1;
    }

    public double getRequiredPercentage() {
        return requiredPercentage;
    }

    public int getCurrentWeekCount() {
        return currentWeekCount;
    }

    public void setCurrentWeekCount(int currentWeekCount) {
        this.currentWeekCount = currentWeekCount;
    }

    public String toString() {
        return "Name: " + name + "\nStudent ID: " + studentID + "\nModule ID: " + moduleID + "\nRequired Percentage: " +
                requiredPercentage + "%\n Week Count: " + currentWeekCount;
            }
}